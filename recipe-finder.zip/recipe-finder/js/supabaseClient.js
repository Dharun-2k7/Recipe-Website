// ============================================================
// supabaseClient.js — Initialize Supabase
// IMPORTANT: Replace these with your own project credentials
// from https://supabase.com/dashboard/project/_/settings/api
// ============================================================

const SUPABASE_URL = 'https://YOUR_PROJECT_ID.supabase.co';
const SUPABASE_ANON_KEY = 'YOUR_ANON_KEY';

const { createClient } = supabase;
const supabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export { supabaseClient };
